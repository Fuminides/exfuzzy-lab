"""Stub standing in for the compiled moocore package inside the browser.

pymoo imports ``moocore.hypervolume`` at import time for its hypervolume indicator.
exFuzzy Lab's genetic rule search is single-objective and never computes a hypervolume,
so this stub only exists to let pymoo import in Pyodide. Any call raises.
"""
__version__ = "0.0.0+exfuzzy-lab-stub"


def hypervolume(*args, **kwargs):
    raise RuntimeError("moocore is not available in the browser engine; hypervolume indicators are unsupported here.")
