"""
This file contains the classes to perform rule classification evaluation.
"""
from functools import wraps

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, confusion_matrix

from . import rules
from . import fuzzy_sets as fs
from . import permutation_test as pt
from . import bootstrapping_test as bt


def _shared_firing(method):
    """
    Runs an evaluation method inside the rule base's firing cache scope.

    The support, confidence, dominance and accuracy computations all ask the
    rule base for the same firing strengths. Within the scope the rule base
    computes them once and returns the same array to every request, so the
    values are exactly those of the repeated computations.
    """
    @wraps(method)
    def wrapped(self, *args, **kwargs):
        scope = getattr(self.mrule_base, '_firing_cache_scope', None)
        if scope is None:
            return method(self, *args, **kwargs)
        with scope():
            return method(self, *args, **kwargs)
    return wrapped


class evalRuleBase():
    """
    Class to evaluate a set of rules given a evaluation dataset.
    """

    def __init__(self, mrule_base: rules.MasterRuleBase, X: np.array, y: np.array, time_moments: np.array=None, precomputed_truth=None) -> None:
        """
        Creates the object with the rulebase to evaluate and the data to use in the evaluation.

        Args:
            mrule_base: The rule base to evaluate.
            X: array shape samples x features. The data to evaluate the rule base.
            y: array shape samples x 1. The labels of the data.
            time_moments: array shape samples x 1. The time moments of the samples. (Only for temporal rule bases)

        Returns:
            None
        """
        self.mrule_base = mrule_base
        self.X = X
        self.y = y
        self.time_moments = time_moments

        self.precomputed_truth = precomputed_truth

        if isinstance(np.array(y)[0], str):
            consequents_names = self.mrule_base.get_consequents_names()
            self.y = np.array([list(consequents_names).index(str(y)) for y in y])




    def compute_antecedent_pattern_support(self, X: np.array=None) -> np.array:
        """
        Computes the pattern support for each of the rules for the given X.
        Each pattern support firing strength is the result of the tnorm for all the antecedent memeberships,
        dvided by their number.

        Returns:
            array of shape rules x 2
        """
        data_X = X if X is not None else self.X
        precomputed_truth = self.precomputed_truth if self.precomputed_truth is not None else None

        if self.time_moments is None:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
                data_X, precomputed_truth=precomputed_truth)
        else:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
                data_X, self.time_moments)


        patterns = self._get_all_rules()

        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t1:
            res = np.zeros((len(patterns), ))
        elif self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2:
            res = np.zeros((len(patterns), 2))
        else:
            res = np.zeros((len(patterns), 2))

        for ix, pattern in enumerate(patterns):
            pattern_firing_strength = antecedent_memberships[:, ix]
            res[ix] = np.mean(pattern_firing_strength, axis=0)

        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2 or self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.gt2:
            res = np.mean(res, axis=1)

        return res

    def compute_pattern_support(self, X: np.array=None, y: np.array=None) -> np.array:

        """
        Computes the pattern support for each of the rules for the given X.
        Each pattern support firing strength is the result of the tnorm for all the antecedent memeberships,
        dvided by their number.

        Returns:
            array of shape rules x 2
        """
        data_X = X if X is not None else self.X
        data_y = y if y is not None else self.y
        precomputed_truth = self.precomputed_truth if self.precomputed_truth is not None else None

        if self.time_moments is None:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
                data_X, precomputed_truth=precomputed_truth)
        else:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
                data_X, self.time_moments)

        patterns = self._get_all_rules()

        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t1:
            res = np.zeros((len(patterns), ))
        elif self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2:
            res = np.zeros((len(patterns), 2))
        else:
            res = np.zeros((len(patterns), 2))

        consequents = self.mrule_base.get_consequents()
        fuzzy_type = self.mrule_base.fuzzy_type()
        for ix, pattern in enumerate(patterns):
            consequent_match = np.array(np.equal(data_y, consequents[ix]), dtype=int)
            pattern_firing_strength = antecedent_memberships[:, ix]

            # Handle T2/GT2 fuzzy sets which have interval-valued memberships
            if fuzzy_type == fs.FUZZY_SETS.t2 or fuzzy_type == fs.FUZZY_SETS.gt2:
                # pattern_firing_strength is (n_samples, 2) for T2
                # Compute support for lower and upper bounds separately
                res[ix, 0] = np.mean(pattern_firing_strength[:, 0] * consequent_match)
                res[ix, 1] = np.mean(pattern_firing_strength[:, 1] * consequent_match)
            else:
                res[ix] = np.mean(pattern_firing_strength.reshape(-1, ) * consequent_match.reshape(-1, ))
            
        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2 or self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.gt2:
            res = np.mean(res, axis=1)

        return res


    def compute_aux_pattern_support(self) -> np.array:

        """
        Computes the pattern support for each of the rules for each of the classes for the given X.
        Each pattern support firing strength is the result of the tnorm for all the antecedent memeberships,
        dvided by their number.

        Returns:
            array of shape rules x 2
        """
        if self.time_moments is None:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
                self.X)
        else:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
                self.X, self.time_moments)

        patterns = self._get_all_rules()
        n_classes = len(np.unique(self.y))

        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t1:
            res = np.zeros((len(patterns), n_classes, ))
        elif self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2:
            res = np.zeros((len(patterns), n_classes, 2))
        else:
            res = np.zeros((len(patterns), n_classes, 2))

        for con_ix in range(n_classes):
            for ix, pattern in enumerate(patterns):
                consequent_match = np.equal(self.y, con_ix)
                pattern_firing_strength = antecedent_memberships[:, ix]
                consequent_match = consequent_match.reshape((-1,) + (1,) * (pattern_firing_strength.ndim - 1))

                res[ix, con_ix] = np.mean(pattern_firing_strength * consequent_match, axis=0)


        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2 or self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.gt2:
            res = np.mean(res, axis=2)

        return res



    def _get_all_rules(self) -> list[rules.RuleSimple]:
        """
        Returns a list of all the rules in the master rule base.

        Returns:
            list of rules.
        """
        res = []
        for jx in self.mrule_base.get_rules():
                res.append(jx)

        return res


    def compute_pattern_confidence(self, X: np.array=None, y: np.array=None, precomputed_truth=None) -> np.array:
        """
        Computes the pattern confidence for each of the rules for the given X.
        Each pattern confidence is the normalized firing strength.

        Returns:
            array of shape 1 x rules
        """
        data_X = X if X is not None else self.X
        data_y = y if y is not None else self.y
        precomputed_truth = self.precomputed_truth if self.precomputed_truth is not None else None

        if self.time_moments is None:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
            data_X, precomputed_truth=precomputed_truth)
        else:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
            data_X, self.time_moments, precomputed_truth=precomputed_truth)


        patterns = self._get_all_rules()

        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t1:
            res = np.zeros((len(patterns), ))
        elif self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2:
            res = np.zeros((len(patterns), 2))
        else:
            res = np.zeros((len(patterns), 2))
        consequents = self.mrule_base.get_consequents()
        for ix, pattern in enumerate(patterns):
            antecedent_consequent_match = np.equal(data_y, consequents[ix])
            pattern_firing_strength = antecedent_memberships[:, ix]
            dem = np.sum(pattern_firing_strength)
            if dem == 0:
                res[ix] = 0
            else:
                res[ix] = np.sum(
                    pattern_firing_strength[antecedent_consequent_match]) / dem

        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2 or self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.gt2:
            res = np.mean(res, axis=1)

        return res



    def compute_aux_pattern_confidence(self) -> np.array:

        """
        Computes the pattern confidence for each of the rules for the given X.
        Each pattern confidence is the normalized firing strength.

        Returns:
            array of shape rules x classes
        """
        if self.time_moments is None:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
            self.X)
        else:
            antecedent_memberships = self.mrule_base.compute_firing_strengths(
            self.X, self.time_moments)

        patterns = self._get_all_rules()
        n_classes = len(np.unique(self.y))
        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t1:
            res = np.zeros((len(patterns), n_classes, ))
        elif self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2:
            res = np.zeros((len(patterns), n_classes, 2))
        else:
            res = np.zeros((len(patterns), n_classes, 2))

        for consequent in range(n_classes):
            for ix, pattern in enumerate(patterns):
                antecedent_consequent_match = self.y == consequent
                pattern_firing_strength = antecedent_memberships[:, ix]
                dem = np.sum(pattern_firing_strength, axis=0)
                matched = np.sum(pattern_firing_strength[antecedent_consequent_match], axis=0)
                res[ix, consequent] = np.divide(matched, dem, out=np.zeros_like(dem, dtype=float), where=dem != 0)

        if self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.t2 or self.mrule_base.fuzzy_type() == fs.FUZZY_SETS.gt2:
            res = np.mean(res, axis=2)

        return res



    @_shared_firing
    def dominance_scores(self) -> np.array:
        """
        Returns the dominance score of each pattern for each rule.

        Returns:
            array of shape rules x 2
        """
        return self.compute_pattern_confidence() * self.compute_pattern_support()


    @_shared_firing
    def association_degree(self) -> np.array:
        """
        Returns the association degree of each rule for each sample.

        Returns:
            vector of shape rules
        """
        if self.time_moments is None:
            firing_strengths = self.mrule_base.compute_firing_strengths(self.X)
        else:
            firing_strengths = self.mrule_base.compute_firing_strengths(self.X, self.time_moments)
        dominance_scores = self.dominance_scores()
        if firing_strengths.ndim == 3:
            dominance_scores = dominance_scores[:, None]
        res = dominance_scores * firing_strengths

        if (self.mrule_base[0].fuzzy_type() == fs.FUZZY_SETS.t2) or (self.mrule_base[0].fuzzy_type() == fs.FUZZY_SETS.gt2):
            res = np.mean(res, axis=2)

        return res


    @_shared_firing
    def aux_dominance_scores(self) -> np.array:
        """
        Returns the dominance score of each pattern for each rule.

        Returns:
            array of shape rules x 2
        """
        return self.compute_aux_pattern_confidence() * self.compute_aux_pattern_support()


    @_shared_firing
    def add_rule_weights(self) -> None:
        """
        Add dominance score field to each of the rules present in the master Rule Base.
        """
        rules = self.mrule_base.get_rules()
        if len(rules) == 0:
            return

        supports = self.compute_pattern_support()
        confidences = self.compute_pattern_confidence()
        scores = self.dominance_scores()

        aux_counter = 0
        for jx in range(len(rules)):
                rules[jx].score = scores[aux_counter]
                rules[jx].support = supports[aux_counter]
                rules[jx].confidence = confidences[aux_counter]
                
                aux_counter += 1
    

    @_shared_firing
    def add_auxiliary_rule_weights(self) -> None:
        """
        Add dominance score field to each of the rules present in the master Rule Base for each consequent.
        They are labeled as aux_score, aux_support and aux_confidence. (Because they are not the main rule weights)
        """
        supports = self.compute_aux_pattern_support()
        confidences = self.compute_aux_pattern_confidence()
        scores = self.aux_dominance_scores()

        aux_counter = 0
        rules = self.mrule_base.get_rules()
        for jx in range(len(rules)):
                rules[jx].aux_score = scores[aux_counter]
                rules[jx].aux_support = supports[aux_counter]
                rules[jx].aux_confidence = confidences[aux_counter]
                
                aux_counter += 1


    @_shared_firing
    def add_classification_metrics(self, X: np.array=None, y: np.array=None) -> None:
        """
        Adds the accuracy of each rule in the master rule base. It also adds the f1, precision and recall scores.
        If X and y are None uses the train set.

        Args:
            X: array of shape samples x features
            y: array of shape samples
        """
        # Early return if no rules exist
        if len(self.mrule_base.get_rules()) == 0:
            return

        if X is not None:
            actual_X = X
            actual_y = y
        else:
            actual_X = self.X
            actual_y = self.y

        if isinstance(actual_y, list):
            actual_y = np.array(actual_y)

        if not hasattr(self.mrule_base.get_rules()[0], 'score'):
            self.add_rule_weights()


        if self.time_moments is None:
            winning_rules, _winning_association_degrees = self.mrule_base._winning_rules(actual_X, precomputed_truth=self.precomputed_truth, allow_unknown=self.mrule_base.allow_unknown)
            preds = self.mrule_base.winning_rule_predict(actual_X, precomputed_truth=self.precomputed_truth)
        else:

            winning_rules, _winning_association_degrees = self.mrule_base._winning_rules(actual_X, self.time_moments)
            preds = self.mrule_base.winning_rule_predict(actual_X, self.time_moments)


        # Predictions are consequent indexes, so they are named when the labels are names.
        consequents_names = self.mrule_base.get_consequents_names()
        if isinstance(actual_y[0], str):
            preds = np.array([str(consequents_names[int(p)]) if p != -1 else 'Unknown' for p in preds])


        rules = self.mrule_base.get_rules()
        for jx in range(len(rules)):
                relevant_samples = winning_rules == jx
                if np.sum(relevant_samples) > 0:
                    relevant_labels = actual_y[relevant_samples]
                    relevant_preds = preds[relevant_samples]

                    rules[jx].accuracy = accuracy_score(relevant_labels, relevant_preds)
                else:
                    rules[jx].accuracy = 0.0
                
    
    @_shared_firing
    def classification_eval(self) -> float:
        """
        Returns the matthews correlation coefficient for a classification task using
        the rules evaluated.

        Returns:
            mattews correlation coefficient. (float in [-1, 1])
        """
        # Handle empty rule base
        if len(self.mrule_base.get_rules()) == 0:
            self.mcc = 0.0
            self.acc = 0.0
            return self.mcc

        from sklearn.metrics import matthews_corrcoef
        self.add_rule_weights()
        if self.time_moments is None:
            preds = self.mrule_base.winning_rule_predict(self.X, precomputed_truth=self.precomputed_truth)
        else:
            preds = self.mrule_base.winning_rule_predict(self.X, self.time_moments)

        self.mcc = matthews_corrcoef(self.y, preds)
        self.acc = accuracy_score(self.y, preds)

        return self.mcc


    def size_antecedents_eval(self, tolerance=0.1) -> float:
        """
        Returns the share of the possible conditions the rule base leaves unused.

        Over the rules whose dominance score exceeds the tolerance, it is 1 - conditions / (rules x input variables),
        so shorter rules score higher. It is 0 when a class has no rules.

        Args:
            tolerance: float in [0, 1]. The tolerance for the dominance score. Default 0.1

        Returns:
            float in [0, 1] with the score.
        """
        possible_rule_size = 0
        effective_rule_size = 0

        for rule_base in self.mrule_base.get_rulebases():
            if len(rule_base) > 0:
                for rule in rule_base:
                    rscore = np.mean(rule.score)
                    if rscore > tolerance:
                        possible_rule_size += len(rule.antecedents)
                        # No antecedents for this rule
                        if sum(np.array(rule.antecedents) != -1) == 0:
                            effective_rule_size += len(rule.antecedents)
                        else:
                            effective_rule_size += sum(
                                np.array(rule.antecedents) != -1)

            else:
                return 0.0  # If one consequent does not have rules, then we return 0.0

        try:
            rule_density = 1 - effective_rule_size / possible_rule_size  # Antecedents used
        except ZeroDivisionError:
            rule_density = 0.0

        return rule_density
    

    def effective_rulesize_eval(self, tolerance=0.1) -> float:
        """
        Returns the share of rules that are effective.

        A rule is effective when its dominance score exceeds the tolerance and it has at least one condition.
        It is 0 when a class has no rules. It does not depend on how many rules there are.

        Args:
            tolerance: float in [0, 1]. The tolerance for the dominance score. Default 0.1

        Returns:
            float in [0, 1] with the score.
        """
        possible_rules = len(self.mrule_base.get_rules())
        effective_rules = 0

        for rule_base in self.mrule_base.get_rulebases():
            if len(rule_base) > 0:
                for rule in rule_base:
                    rscore = np.mean(rule.score)
                    if rscore > tolerance:
                        # No antecedents for this rule
                        if not np.all(np.equal(np.array(rule.antecedents), -1)):
                            effective_rules += 1
                        
            else:
                return 0.0  # If one consequent does not have rules, then we return 0.0

        # Every consequent has at least one rule at this point.
        return effective_rules / possible_rules


    def p_permutation_classifier_validation(self, n=100, r=10) -> float:
        """
        Performs a boostrap test to evaluate the performance of the rule base.
        Returns the p-valuefor the label permutation test and the feature coalition test.

        Args:
            n: int. Number of boostrap samples.
            r: int. Number of repetitions to estimate the original error rate.

        Returns:
            p-value of the permutation test.
        """
        test1 = pt.permutation_labels_test(self.mrule_base, self.X, self.y, k=n, r=r)
        test2 = pt.permute_columns_class_test(self.mrule_base, self.X, self.y, k=n, r=r)

        pt.rulewise_label_permutation_test(self.mrule_base, self.X, self.y, k=n, r=r)
        pt.rulewise_column_permutation_test(self.mrule_base, self.X, self.y, k=n, r=r)

        self.mrule_base.p_value_class_structure = test1
        self.mrule_base.p_value_feature_coalition = test2

        return test1, test2
    

    def p_bootstrapping_rules_validation(self, n=100) -> float:
        rules_p_values =  bt.compute_rule_p_value(self.mrule_base, self.X, self.y, n).flatten()

        for jx, rule in enumerate(self.mrule_base.get_rules()):
            rule.boot_p_value = rules_p_values[jx]
        
        confidence_interval = self.bootstrap_confidence_confinterval(self.X, self.y, n)
        support_interval = self.bootstrap_support_confinterval(self.X, self.y, n)

        for jx, rule in enumerate(self.mrule_base.get_rules()):
            rule.boot_confidence_interval = confidence_interval[:, jx]
            rule.boot_support_interval = support_interval[:, jx]



    @_shared_firing
    def add_full_evaluation(self):

        """
        Adds classification scores, both Dominance Scores and accuracy metrics, for each individual rule.
        """
        self.add_rule_weights()
        self.add_classification_metrics()
        self.classification_eval()
    

    def bootstrap_support_rules(self, X: np.array, y: np.array, n_samples: int):
        """
        Bootstraps the support of the rules in the classifier.
        """
        samples = bt.generate_bootstrap_samples(X, y, n_samples)
        supports = np.zeros((n_samples, len(self.mrule_base.get_rules())))
    

        for i, sample in enumerate(samples):
            supports[i] = self.compute_pattern_support(sample[0], sample[1])
    
        return supports


    def bootstrap_confidence_rules(self, X: np.array, y: np.array, n_samples: int):
        """
        Bootstraps the confidence of the rules in the classifier.
        """
        samples = bt.generate_bootstrap_samples(X, np.array(y), n_samples)
        confidences = np.zeros((n_samples, len(self.mrule_base.get_rules())))

        for i, sample in enumerate(samples):
            confidences[i] = self.compute_pattern_confidence(sample[0], sample[1])
    
        return confidences


    def bootstrap_support_confinterval(self, X: np.array, y: np.array, n_samples: int):
        """
        Bootstraps the support of the rules in the classifier.
        """
        supports = self.bootstrap_support_rules(X, np.array(y), n_samples)
        conf_interval = np.percentile(supports, [2.5, 97.5], axis=0)
        return conf_interval



    def bootstrap_confidence_confinterval(self, X: np.array, y: np.array, n_samples: int):
        """
        Bootstraps the confidence of the rules in the classifier.
        """
        confidences = self.bootstrap_confidence_rules(X, np.array(y), n_samples)
        conf_interval = np.percentile(confidences, [2.5, 97.5], axis=0)
        return conf_interval
